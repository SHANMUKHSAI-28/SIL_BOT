import pyautogui
import time

def refresh():
    try:
        refresh_button = pyautogui.locateOnScreen('taskbar.png', confidence=0.5)
        if refresh_button is not None:
            refresh_button = (refresh_button.left + 25, refresh_button.top - 140, refresh_button.height - 20, refresh_button.width - 50)
            pyautogui.click(refresh_button)
            return 1
        else:
            print("Taskbar button not found.")
            return 0
    except pyautogui.ImageNotFoundException:
        print("Image not found. Running another method.")
        availablecheck()
        return 0

def availablecheck():
    try:
        if loading() == 1:
            is_available = pyautogui.locateOnScreen('register.png', confidence=0.5)
            if is_available is not None:
                pyautogui.click(is_available)
                print(is_available)
                register()
                return 1
            else:
                print("av0.png not found.")
                return 0
        else:
            return 0  # Added return statement here
    except pyautogui.ImageNotFoundException:
        refresh()

def register():
    try:
        submit = pyautogui.locateOnScreen('submit.png', confidence=0.1)  # Corrected the image filename
        pyautogui.click(1076,707)
        print(submit)
        print('clicked submit')
        if submit is None:
            refresh()
    except pyautogui.ImageNotFoundException:
        refresh()

def loading():
    try:
        submit = pyautogui.locateOnScreen('loading.png', confidence=0.1) or pyautogui.locateOnScreen('load2.png',confidence=0.5) or pyautogui.locateOnScreen('load3.png',confidence=0.5)
        print('waiting to load')
        time.sleep(0.5)
        return 1
    except pyautogui.ImageNotFoundException:
        return 0  # Added return statement here

if __name__ == "__main__":
    while True:
        if availablecheck() == 1:
            refresh()
