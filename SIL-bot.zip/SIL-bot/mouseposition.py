import pyautogui
import time
# Repeat for 10 times
for _ in range(10):
    # Get the current mouse position
    mouse_l, mouse_t = pyautogui.position()
    time.sleep(1)

    # Print the mouse position
    print(f"Mouse position: x={mouse_l}, y={mouse_t}")
